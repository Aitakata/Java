/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package fj11_capitulo4;

/**
 *
 * @author artur
 */
class Data {
int dia;
int mes;
int ano;
}

class Funcionario {
        // atributos
    String nome;
    String departamento;
    String rg;
    Data dataEntrada;
    Double salario;
        
    void recebeAumento(double aumento) {
    // incorpora aumento em salario
       this.salario += aumento;
    }
    double calculaGanhoAnual() {
    // soma o salario de 12 meses
       return this.salario * 12;
    }
        
    void mostra (){
       System.out.println("Funcionario=  "+this.nome);
       System.out.println("Departamento= "+this.departamento);
       System.out.println("RG= "+this.rg);
       System.out.println("Data de entrada = "+this.dataEntrada.dia+
               "\\"+this.dataEntrada.mes+"\\"+this.dataEntrada.ano);
       System.out.println("Salario=    "+this.salario);
    }
}

public class FJ11_Capitulo4 {

    /**
     * @param args the command line arguments
     */

    public static void main(String[] args) {
        // 
        Funcionario f1= new Funcionario();     
        f1.nome="Hugo";
        f1.salario = 100.00;
        f1.recebeAumento (50);
        Data data= new Data(); f1.dataEntrada= data;
        f1.dataEntrada.dia= 07; f1.dataEntrada.mes=11; f1.dataEntrada.ano=1962;

        System.out.println("salario atual:"+f1.salario);
        System.out.println("ganha anual:"+f1.calculaGanhoAnual());
        f1.mostra();
        
        Funcionario f2= new Funcionario();
        f2.nome= "Danilo";
        f2.salario= 150.00;
        
        if (f1 == f2){
            System.out.println("inicialmente f1 e f2 sao iguais");
        } else {
            System.out.println("Inicialmente f1 e f2 sao diferentes");
        };
        System.out.println("Nome de f2 e "+f2.nome);
        f2= f1;   // agora os ponteiros de fi e f2 apontam  para a mesma posiçao
        if (f1 == f2){
            System.out.println("Agora f1 e f2 sao iguais");
        } else {
            System.out.println("Agora f1 e f2 sao diferentes");
        };
        System.out.println("Nome de f2 e "+f2.nome);
    }
    
}
