/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package fj11_capitulo3;

import java.util.Scanner;

/**
 *
 * @author artur
 * Curso FJ-11 - Java e Orientaçao a Objetos
 * lista de exercicio 3.1 do capitulo 3
 */
public class FJ11_capitulo3 {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
    // Estruturado como um switch com os exercicios relevantes sendo uma opção 
      int opc = 0;
      while (opc != 8) {
        System.out.println ("\n\nFJ11 - Capitulo 3");
        System.out.println ("  1 - Numeros de 150 a 300");
        System.out.println ("  2 - Multiplos de 3 entre 1 a 100");
        System.out.println ("  3 - Fatorial de 1 a 10");
        System.out.println ("  4 - Fibonacci menor que 100");
        System.out.println ("  5 - Se x e par=x/2, senao x= 3*x+1");
        System.out.println ("  6 - Imprimir tabela");
        System.out.println ("      1");
        System.out.println ("      2 4");
        System.out.println ("      3 6 9");
        System.out.println ("      n n*2 n*3 ... n*n");
        System.out.println ("  7 - Fibonacci com 2 variaveis");
        System.out.println ("  8 - Sair do programa");
        Scanner reader = new Scanner(System.in);
        System.out.print ("Escolha uma atividade ");
        opc = reader.nextInt();
        switch (opc){
          case 1:  
              imp150_300();
              break;
          case 2:
              mult_3();
              break;
          case 3:
              fat();
              break;
          case 4:
              fibonacci_lt_100();
              break;
          case 5:
              par_impar();
              break;
          case 6:
              tabela();
              break;
          case 7:
              fibonacci_2var();
          case 8:
              System.out.println ("  Saindo ...");
              break;
          default:    
              System.out.println ("  Opção invalida!!");
        }
      } // loop de opçoes 
      System.out.println ("Obrigado! ");
   
    }
    
    protected static void imp150_300(){
      System.out.println ("  Atividade 3.1 Imprimir numeros de 150 a 300 ");
      for (int i=150; i<=300; i++){
          System.out.println("Valor de i="+i);
      }    
    }
    
    protected static void mult_3(){
      System.out.println ("  Atividade 3.2 Multiplos de 3 entre 1 e 100 ");
      for (int i=3; i<=100; i+=3){
          System.out.println("Valor de i="+i);
      }
    }
    
    protected static void fat(){
      System.out.println ("  Atividade 3.3 Fatorial de 1 a 10");
      int result=1;
      for (int i=1; i<=10; i++){
        for (int j=1; j<= i; j++){
            result *= j;
        };
        System.out.printf("fatorial de (%d)=%d\n",i,result);
        result=1;
      }
    }
    
    protected static void fibonacci_lt_100(){
      int p= 0; int s=1;
      int fib= p+s;
      System.out.println ("  Atividade 3.4 Fibonacci menor do que 100 ");
      System.out.printf("0,1");
      while (fib < 100){
        System.out.print(","+fib);
        p=s; s=fib; fib=p+s;
      }
      System.out.println();
    }

    protected static void par_impar(){
      int x=13;
      System.out.println ("  Atividade 3.5 Se x e par=x/2, senao x= 3*x+1");    
      while (x != 1){
         if ((x % 2) == 0) {
            x = x/2;} 
         else {
            x = 3 * x + 1;};
         System.out.println("x="+x);
      }
    }
    
    protected static void tabela(){
    /* exercicio 6 - Imprima a tabela
    1
    2  4
    3  6   9
    4  8   12  16
    n  n*2 n*3 ... n*n         */
        int n=6;
        System.out.println ("  Atividade 3.6 Imprimir tabela");
        for (int i=1; i <= n; i++) {
          for (int j=1; j<= i; j++) {
             System.out.print(i*j+" ");
          }
          System.out.println();
        }
    }
    
    protected static void fibonacci_2var(){
      System.out.println ("  Atividade 3.7 Fibonacci com 2 variaveis");
      for (int i= 0; fibo(i) <= 100; i++){
        System.out.println("Fibonacci de "+i+" é="+fibo(i));
      }
    }
    
    protected static int fibo(int x){
      if (x == 0) {
         return (0);
      } else 
      if (x == 1) {
        return (1);
      } else
        return (fibo (x-1)+fibo(x -2));
    }

}

